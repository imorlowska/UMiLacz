/****************************************************************************
**
** Copyright (C) 2010 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
** Contact: Nokia Corporation (qt-info@nokia.com)
**
** This file is part of the QML project on Qt Labs.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Nokia Corporation and its Subsidiary(-ies) nor
**     the names of its contributors may be used to endorse or promote
**     products derived from this software without specific prior written
**     permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef QOBJECTLISTMODEL_H
#define QOBJECTLISTMODEL_H

#include <list>
#include <type_traits>
using namespace std;

#include <QAbstractListModel>

/*
    Open issues:
        object ownership: is it helpful for the model to own the objects?
                          can we guard the objects so they are automatically removed
                              from the model when deleted?
        add additional QList convenience functions (operator<<, etc.)
*/



template <class Obj,class Proj>
class QObjectListModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(int count READ count NOTIFY countChanged)
	static_assert(is_base_of<QObject,Proj>::value,"Projection must be derived from QObject");
public:
	//explicit QObjectListModel(QObject *parent = 0);
	QObjectListModel(list<Obj*>& lObjects, QObject *parent = 0);

    //model API
    enum Roles { ObjectRole = Qt::UserRole+1 };

    int rowCount(const QModelIndex &parent) const;
    QVariant data(const QModelIndex &index, int role) const;

	QObjectList& objectList() const;
	void setObjectList(QObjectList& objects);

    //list API
    void append(QObject *object);
    void append(const QObjectList &objects);
    void insert(int i, QObject *object);
    void insert(int i, const QObjectList &objects);

	inline QObject *at(int i) const { return projections.at(i); }
	inline QObject *operator[](int i) const { return projections[i]; }
    void replace(int i, QObject *object);

    void move(int from, int to);

    void removeAt(int i, int count = 1);
    QObject *takeAt(int i);
    void clear();

	inline bool contains(QObject *object) const { return projections.contains(object); }
	inline int indexOf (QObject *object, int from = 0) const { return projections.indexOf(object, from); }
	inline int lastIndexOf (QObject *object, int from = -1) const { return projections.lastIndexOf(object, from); }

	inline int count() const { return projections.count(); }
	inline int size() const { return projections.size(); }
	inline bool isEmpty() const { return projections.isEmpty(); }

    //additional QML API
    Q_INVOKABLE QObject *get(int i) const;
	Q_INVOKABLE void remove(int i);
	Q_INVOKABLE void addEmpty();
	QHash<int, QByteArray> roleNames() const;
Q_SIGNALS:
    void countChanged();

private:
    Q_DISABLE_COPY(QObjectListModel)
protected:
	QObjectList projections;
	list<Obj*>* objects;

};

template <class Obj,class Proj>
QHash<int, QByteArray> QObjectListModel<Obj,Proj>::roleNames() const
{
	QHash<int, QByteArray> roles;
	roles[ObjectRole] = "object";

	return roles;
}


/*!
	Constructs an object list model containing the specified \a objects
	with the given \a parent.
*/
template <class Obj,class Proj>
QObjectListModel<Obj,Proj>::QObjectListModel(list<Obj*>& lObjects, QObject *parent) :
	QAbstractListModel(parent),objects(&lObjects)
{

	for(auto it=objects->begin();it!=objects->end();it++)
		projections.append(new Proj(*it));
}

/*!
	Returns data for the specified \a role, from the item with the
	given \a index. The only valid role is \c ObjectRole.

	If the view requests an invalid index or role, an invalid variant
	is returned.
*/
template <class Obj,class Proj>
QVariant QObjectListModel<Obj,Proj>::data(const QModelIndex &index, int role) const
{
	if (index.row() < 0 || index.row() >= projections.size())
		return QVariant();

	if (role == ObjectRole)
		return QVariant::fromValue(projections.at(index.row()));

	return QVariant();
}

/*!
	Returns the number of rows in the model. This value corresponds to the
	number of items in the model's internal object list.
*/
template <class Obj,class Proj>
int QObjectListModel<Obj,Proj>::rowCount(const QModelIndex &parent) const
{
	Q_UNUSED(parent);
	return count();
}

/*!
	Returns the object list used by the model to store data.
*/
template <class Obj,class Proj>
QObjectList& QObjectListModel<Obj,Proj>::objectList() const
{
	return projections;
}

/*!
	Sets the model's internal objects list to \a objects. The model will
	notify any attached views that its underlying data has changed.
*/
template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::setObjectList(QObjectList& objects)
{
	int oldCount = projections.count();
	beginResetModel();
	projections = &objects;
	endResetModel();
	emit dataChanged(index(0), index(projections.count()));
	if (projections.count() != oldCount)
		emit countChanged();
}

/*!
	Inserts \a object at the end of the model and notifies any views.

	This is the same as model.insert(size(), \a object).

	\sa insert()
*/
template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::append(QObject *object)
{
	beginInsertRows(QModelIndex(), projections.count(), projections.count());
	projections.append(object);
	endInsertRows();
	emit countChanged();
}

/*!
	\overload
	Appends the items of the \a objects list to this model and notifies any views.
*/
template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::append(const QObjectList &objects)
{
	beginInsertRows(QModelIndex(), projections.count(), projections.count()+objects.count()-1);
	projections.append(objects);
	endInsertRows();
	emit countChanged();
}

/*!
	Inserts \a object at index position \a i in the model and notifies
	any views. If \a i is 0, the object is prepended to the model. If \a i
	is size(), the object is appended to the list.

	\sa append(), replace(), removeAt()
*/
template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::insert(int i, QObject *object)
{
	beginInsertRows(QModelIndex(), i, i);
	projections.insert(i, object);
	endInsertRows();
	emit countChanged();
}

/*!
	\overload
	Inserts the items of the \a objects list at index position \a i in the model
	and notifies any views. If \a i is 0, the items are prepended to the model. If \a i
	is size(), the items are appended to the list.
*/
template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::insert(int i, const QObjectList &objects)
{
	if (objects.isEmpty())
		return;

	beginInsertRows(QModelIndex(), i, i+objects.count()-1);
	for (int j = objects.count() - 1; j > -1; --j)
		projections.insert(i, objects.at(j));
	endInsertRows();
	emit countChanged();
}

/*!
	Replaces the item at index position \a i with \a object and
	notifies any views. \a i must be a valid index position in the list
	(i.e., 0 <= \a i < size()).

	\sa removeAt()
*/
template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::replace(int i, QObject *object)
{
	projections.replace(i, object);
	emit dataChanged(index(i), index(i));
}

/*!
	Moves the item at index position \a from to index position \a to
	and notifies any views.

	This function
	assumes that both \a from and \a to are at least 0 but less than
	size(). To avoid failure, test that both \a from and \a to are at
	least 0 and less than size().
*/


template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::move(int from, int to)
{
	if (!beginMoveRows(QModelIndex(), from, from, QModelIndex(), to > from ? to+1 : to))
		return; //should only be triggered for our simple case if from == to.
	projections.move(from, to);
	endMoveRows();
}

/*!
	Removes \a count number of items from index position \a i and notifies any views.
	\a i must be a valid index position in the model (i.e., 0 <= \a i < size()), as
	must \c{i + count - 1}.

	\sa takeAt()
*/
template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::removeAt(int i, int count)
{
	beginRemoveRows(QModelIndex(), i, i + count - 1);
	for (int j = 0; j < count; ++j)
		projections.removeAt(i);
	endRemoveRows();
	emit countChanged();
}

/*!
	Removes the item at index position \a i (notifying any views) and returns it.
	\a i must be a valid index position in the model (i.e., 0 <= \a i < size()).

	\sa removeAt()
*/

template <class Obj,class Proj>
QObject *QObjectListModel<Obj,Proj>::takeAt(int i)
{
	beginRemoveRows(QModelIndex(), i, i);
	QObject *obj = projections.takeAt(i);
	endRemoveRows();
	emit countChanged();
	return obj;
}

/*!
	Removes all items from the model and notifies any views.
*/

template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::clear()
{
	if (projections.isEmpty())
		return;

	beginRemoveRows(QModelIndex(), 0, projections.count() - 1);
	projections.clear();
	endRemoveRows();
	emit countChanged();
}

/*!
	\internal
	For usage from QML.
*/

template <class Obj,class Proj>
QObject *QObjectListModel<Obj,Proj>::get(int i) const
{
	return projections.at(i);
}

template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::remove(int i)
{
	removeAt(i);
}

template <class Obj,class Proj>
void QObjectListModel<Obj,Proj>::addEmpty()
{
	Obj* n = new Obj();
	objects->push_back(n);
	projections.append(Proj(n));
	emit countChanged();
}

#endif // QOBJECTMODEL_H
