/****************************************************************************
**
** Copyright (C) 2010 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
** Contact: Nokia Corporation (qt-info@nokia.com)
**
** This file is part of the QML project on Qt Labs.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Nokia Corporation and its Subsidiary(-ies) nor
**     the names of its contributors may be used to endorse or promote
**     products derived from this software without specific prior written
**     permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
** $QT_END_LICENSE$
**
****************************************************************************/

#include "qobjectlistmodel.h"

/*!
    \class QObjectListModel
    \brief The QObjectListModel class provides a model that supplies objects to QML views.

    QObjectListModel provides a more powerful, but still easy to use, alternative to using
    QObjectList lists as models for QML views. As a QAbstractListModel, it has the ability to
    automatically notify the view of specific changes to the list, such as adding or removing
    items. At the same time it provides QList-like convenience functions such as append, at,
    and removeAt for easily working with the model from C++.

    \code
    QObjectListModel model;
    model.setObjectList(myQList);
    model.append(myNewObject);
    ...
    int pos = model.indexOf(myObject);
    model.insert(pos, myOtherNewObject);
    ...
    model.removeAt(0);
    \endcode

    QObjectListModel exposes a single \c object role to QML,
    as well as a \c count property, and a \c get(int i) function.

    \qml
    ListView {
        ...
        delegate: Text { text: object.someProperty }
    }
    \endqml
*/

/*!
    Constructs an object list model with the given \a parent.
*/
//QObjectListModel::QObjectListModel(QObject *parent) :
//    QAbstractListModel(parent)
//{
//	//QHash<int, QByteArray> roles;
//	//roles[ObjectRole] = "object";
//	//setRoleNames(roles);
//}





/*!
    \fn int QObjectListModel::size() const

    Returns the number of items in the model.

    \sa isEmpty(), count()
*/

/*! \fn int QObjectListModel::count() const

    Returns the number of items in the model. This is effectively the
    same as size().
*/

/*! \fn bool QObjectListModel::isEmpty() const

    Returns true if the model contains no items; otherwise returns
    false.

    \sa size()
*/

/*! \fn QObject *QObjectListModel::at(int i) const

    Returns the object at index position \a i in the list. \a i must be
    a valid index position in the model (i.e., 0 <= \a i < size()).

    \sa operator[]()
*/

/*! \fn QObject *QObjectListModel::operator[](int i) const

    \overload

    Same as at().
*/

/*! \fn int QObjectListModel::indexOf(QObject *object, int from = 0) const

    Returns the index position of the first occurrence of \a object in
    the model, searching forward from index position \a from. Returns
    -1 if no item matched.

    \sa lastIndexOf(), contains()
*/

/*! \fn int QObjectListModel::lastIndexOf(QObject *object, int from = -1) const

    Returns the index position of the last occurrence of \a object in
    the list, searching backward from index position \a from. If \a
    from is -1 (the default), the search starts at the last item.
    Returns -1 if no item matched.

    \sa indexOf()
*/

/*! \fn bool QObjectListModel::contains(Object *object) const

    Returns true if the list contains an occurrence of \a object;
    otherwise returns false.

    \sa indexOf(), count()
*/


